<?php
    ob_start();
    // include header.php file
    include ('header.php');
?>

<?php

    /*  include banner area  */
        include ('Template/_banner-area.php');
    /*  include banner area  */

    /*  include featured sale section */
        include ('Template/_top-sale.php');
    /*  include featured sale section */

    /*  include new arrival section  */
         include ('Template/_new-arrival.php');
    /*  include new arrival section  */

    /*  include banner ads  */
        include ('Template/_banner-ads.php');
    /*  include banner ads  */

    /*  include men products section  */
        include ('Template/_men-products.php');
    /*  include men products section  */

    /*  include blog area  */
         include ('Template/_blogs.php');
    /*  include blog area  */

?>


<?php
// include footer.php file
include ('footer.php');
?>