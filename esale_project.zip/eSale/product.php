<?php
// include header.php file
include ('header.php');
?>

<?php

    /*  include products */
    include ('Template/_products.php');
    /*  include products */

    /*  include new arrival section */
    include ('Template/_new-arrival.php');
    /*  include new arrival section */

    /*  include men products section */
    include ('Template/_men-products.php');
    /*  include men products section */

?>

<?php
// include footer.php file
include ('footer.php');
?>

