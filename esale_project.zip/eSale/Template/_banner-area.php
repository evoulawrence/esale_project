<!-- Owl-carousel -->
<section id="banner-area">
    <div class="owl-carousel owl-theme">
        <div class="item banner-container">
            <img src="./assets/wrist-watches_925x.png" alt="Banner1" class="image-fluid">
            <div class="banner-caption">
                <div class="banner-overlay-text">
                    <p class="banner-overlay py-0" style="font-size: 30px;">Nice Watch</p>
                    <p class="banner-overlay font-size-20 py-0">Cheaper Price</p>
                </div>
                <button type="submit" name="banner_see_more" class="btn font-size-16 color-primary-bg mt-2 px-5 py-2 text-white banner-action">See More</button>
            </div>
        </div>

    </div>
</section>
<!-- !Owl-carousel -->
