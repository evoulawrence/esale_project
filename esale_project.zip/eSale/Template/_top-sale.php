<!-- Top Sale -->
<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

shuffle($featured_product);
?>
<!-- Featured -->
<section id="top-sale">
    <div class="container-fluid px-0">
        <!-- owl carousel -->
        <div class="owl-carousel owl-theme">
            <?php foreach ($featured_product as $item) { ?>
                <div class="item">
                    <div class="product font-rale featured-product-container">
                        <img src="<?php echo $item['item_image'] ?? "./assets/products/1.png"; ?>" alt="product1" class="img-fluid">
                        <a href="<?php printf('%s?item_id=%s', 'product.php',  $item['item_id']); ?>"><button type="submit" name="featured_sale_submit" class="btn color-primary-bg text-weight-bold font-size-12 shop-now">SHOP NOW</button></a>
                    </div>
                </div>
            <?php } // closing foreach function ?>
        </div>
        <!-- !owl carousel -->
    </div>
</section>

<!-- !Featured -->