<!-- Special Price -->
<?php
    $brand = array_map(function ($pro){ return $pro['item_brand']; }, $product_shuffle);
    $unique = array_unique($brand);
    //sort($new_arrivals);
    shuffle($new_arrivals);

// request method post
if($_SERVER['REQUEST_METHOD'] == "POST"){
    if (isset($_POST['special_price_submit'])){
        // call method addToCart
        $Cart->addToCart($_POST['user_id'], $_POST['item_id']);
    }
}

$in_cart = $Cart->getCartId($product->getData('cart'));

?>
<!-- New Arrival -->
<section id="new-arrival" class="pt-4">
    <div class="container">
        <h4 class="font-rubik font-size-20 section-header">NEW ARRIVAL</h4>
        <div class="row">
            <?php foreach ($new_arrivals as $item) { ?>
            <div class="product font-rale col-sm new-arrival-container">
                <a href="<?php printf('%s?item_id=%s', 'product.php',  $item['item_id']); ?>"><img src="<?php echo $item['item_image'] ?? "./assets/products/1.png"; ?>" alt="product1" class="img-fluid"></a>
                <div class="new-arrival-details pt-3">
                    <h6 class="pl-4 font-weight-bold text-uppercase">$<?php echo $item['item_name'] ?? 'NA' ; ?></h6>
                    <div class="price pr-4">
                        <span>$<?php echo $item['item_price'] ?? '0' ; ?></span>
                    </div>
                </div>
            </div>
            <?php } // closing foreach function ?>
        </div>
    </div>
</section>
<!-- !New Arrival -->
