<!-- Banner Ads  -->
<section id="banner_adds">
    <div class="container pt-5 text-center">
        <img src="./assets/banner-ads.jpg" alt="banner1" height="300px" class="image-fluid">
        <img src="./assets/wooden-watch_925x.jpg" alt="banner2" height="300px" class="image-fluid ad-second-image">
    </div>
</section>
<!-- !Banner Ads  -->
