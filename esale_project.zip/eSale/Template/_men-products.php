<!-- Featured men products -->
<?php
shuffle($featured_men_products);

?>
<section id="men-section" class="pt-4">
    <div class="container">
        <h4 class="font-rubik font-size-20 section-header">MEN</h4>
        <div class="row">
            <?php foreach ($featured_men_products as $item) { ?>
            <div class="product font-rale col-sm men-section-container">
                <a href="<?php printf('%s?item_id=%s', 'product.php',  $item['item_id']); ?>"><img src="<?php echo $item['item_image'] ?? "./assets/products/1.png"; ?>" alt="product1" class="img-fluid"></a>
                <div class="men-section-details pt-3">
                    <h6 class="pl-4 font-weight-bold text-uppercase"><?php echo $item['item_name'] ?? 'NA' ; ?></h6>
                    <div class="rating text-white font-size-12 men-rating">
                        <span><i class="fas fa-star"></i></span>
                        <span><i class="fas fa-star"></i></span>
                        <span><i class="fas fa-star"></i></span>
                        <span><i class="fas fa-star"></i></span>
                        <span><i class="far fa-star"></i></span>
                    </div>
                    <div class="price pr-4">
                        <span>$<?php echo $item['item_price'] ?? '0.00' ; ?></span>
                    </div>
                </div>
            </div>
            <?php } // closing foreach function ?>
        </div>
    </div>
</section>
<!-- !Men Section -->