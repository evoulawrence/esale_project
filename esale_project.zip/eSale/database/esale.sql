-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 01, 2021 at 12:46 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `esale`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `cart_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`cart_id`, `user_id`, `item_id`) VALUES
(3, 1, 9),
(4, 1, 7);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `item_id` int(11) NOT NULL,
  `item_brand` varchar(200) NOT NULL,
  `item_name` varchar(255) NOT NULL,
  `item_price` double(11,2) NOT NULL,
  `item_image` varchar(255) NOT NULL,
  `item_featured` tinyint(1) NOT NULL DEFAULT 0,
  `item_men_featured` tinyint(1) NOT NULL DEFAULT 0,
  `item_register` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`item_id`, `item_brand`, `item_name`, `item_price`, `item_image`, `item_featured`, `item_men_featured`, `item_register`) VALUES
(4, 'Watch', 'Flecko', 250.00, './assets/products/modern-bamboo-wristwatch_925x.jpg', 0, 1, '2021-11-30 06:55:41'),
(5, 'Watch', 'Bean', 300.00, './assets/products/unique-display-turquoise-watch_925x.jpg', 0, 1, '2021-11-30 06:57:00'),
(6, 'Watch', 'Feloi', 120.00, './assets/products/wood-leather-watches_925x.jpg', 0, 1, '2021-11-30 06:58:06'),
(7, 'Cream', 'DIY Beard Balm', 300.00, './assets/products/DIY-beard-balm_925x.jpg', 1, 0, '2021-11-30 07:01:32'),
(8, 'Shirt', 'Green T-Shirt', 50.00, './assets/products/green-t-shirt_925x.jpg', 1, 0, '2021-11-30 07:01:32'),
(9, 'Bracelet', 'Men Bracelet', 50.00, './assets/products/anchor-bracelet-mens_925x.jpg', 1, 0, '2021-11-30 07:02:52'),
(10, 'Sneakers', 'MC Fly', 200.00, './assets/products/pair-of-navy-blue-skate-shoes_925x.jpg', 0, 0, '2021-11-30 06:51:14'),
(11, 'Sneakers', 'Bearnest', 100.00, './assets/products/black-and-white-running-shoe_925x.jpg', 0, 0, '2021-11-30 06:53:02'),
(12, 'Sneakers', 'Backed', 150.00, './assets/products/light-up-sneakers-women_925x.jpg', 0, 0, '2021-11-30 06:53:59');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `first_name` varchar(225) NOT NULL,
  `last_name` varchar(225) NOT NULL,
  `email_address` varchar(200) DEFAULT NULL,
  `register_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`cart_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`item_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `cart_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
