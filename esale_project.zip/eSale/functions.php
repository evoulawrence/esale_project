<?php

// require MySQL Connection
require ('database/DBController.php');

// require Product Class
require ('database/Product.php');

// require Cart Class
require ('database/Cart.php');


// DBController object
$db = new DBController();

// Product object
$product = new Product($db);
$product_shuffle = $product->getData();

//featured product object
$featured_product = $product->getProductFeatured();

//new arrivals
$new_arrivals = $product->getNewArrivals();

//Featured men products
$featured_men_products = $product->getMenFeatured();

// Cart object
$Cart = new Cart($db );
